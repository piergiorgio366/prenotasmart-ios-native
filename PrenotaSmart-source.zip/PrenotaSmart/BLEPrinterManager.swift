import Foundation
import CoreBluetooth

final class BLEPrinterManager: NSObject, CBCentralManagerDelegate, CBPeripheralDelegate {
    private var central: CBCentralManager!
    private var devices: [UUID: CBPeripheral] = [:]
    private var writable: [UUID: CBCharacteristic] = [:]
    private var scanContinuation: CheckedContinuation<[[String: Any]], Error>?
    private var connectContinuations: [UUID: CheckedContinuation<Void, Error>] = [:]
    private var writeContinuations: [UUID: CheckedContinuation<Void, Error>] = [:]
    private var timeoutItems: [UUID: DispatchWorkItem] = [:]
    private var scanTimer: Timer?

    override init() {
        super.init()
        central = CBCentralManager(delegate: self, queue: .main)
    }

    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if central.state == .poweredOff || central.state == .unauthorized || central.state == .unsupported {
            scanContinuation?.resume(throwing: NativeError.bluetoothDisabled)
            scanContinuation = nil
        }
    }

    @MainActor
    func scan(seconds: TimeInterval = 4.0) async throws -> [[String: Any]] {
        guard central.state == .poweredOn else { throw NativeError.bluetoothDisabled }
        return try await withCheckedThrowingContinuation { continuation in
            scanContinuation = continuation
            central.scanForPeripherals(withServices: nil, options: [CBCentralManagerScanOptionAllowDuplicatesKey: false])
            scanTimer?.invalidate()
            scanTimer = Timer.scheduledTimer(withTimeInterval: seconds, repeats: false) { [weak self] _ in self?.finishScan() }
        }
    }

    private func finishScan() {
        central.stopScan()
        let printers = devices.values.map { peripheral -> [String: Any] in
            let name = peripheral.name ?? "Dispositivo BLE"
            return [
                "address": peripheral.identifier.uuidString,
                "id": peripheral.identifier.uuidString,
                "name": name,
                "transport": "bluetooth",
                "paired": peripheral.state == .connected,
                "connected": peripheral.state == .connected,
                "printCapable": true,
                "confidence": Self.looksLikePrinter(name) ? "high" : "low"
            ]
        }.sorted { String(describing: $0["name"]) < String(describing: $1["name"]) }
        scanContinuation?.resume(returning: printers)
        scanContinuation = nil
    }

    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String: Any], rssi RSSI: NSNumber) {
        devices[peripheral.identifier] = peripheral
    }

    @MainActor
    func connect(identifier: String) async throws {
        guard central.state == .poweredOn else { throw NativeError.bluetoothDisabled }
        guard let uuid = UUID(uuidString: identifier) else { throw NativeError.deviceNotFound }
        if devices[uuid] == nil { devices[uuid] = central.retrievePeripherals(withIdentifiers: [uuid]).first }
        guard let peripheral = devices[uuid] else { throw NativeError.deviceNotFound }
        if peripheral.state == .connected, writable[uuid] != nil { return }
        try await withCheckedThrowingContinuation { continuation in
            connectContinuations[uuid] = continuation
            peripheral.delegate = self
            central.connect(peripheral, options: nil)
            let timeout = DispatchWorkItem { [weak self] in self?.failConnect(uuid, error: NativeError.connectionTimeout) }
            timeoutItems[uuid] = timeout
            DispatchQueue.main.asyncAfter(deadline: .now() + 10, execute: timeout)
        }
    }

    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        peripheral.delegate = self
        peripheral.discoverServices(nil)
    }

    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        failConnect(peripheral.identifier, error: NativeError.connectionFailed(error?.localizedDescription ?? "Connessione Bluetooth non riuscita."))
    }

    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        writable.removeValue(forKey: peripheral.identifier)
    }

    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        if let error { failConnect(peripheral.identifier, error: error); return }
        guard let services = peripheral.services, !services.isEmpty else {
            failConnect(peripheral.identifier, error: NativeError.unsupported("Nessun servizio BLE disponibile.")); return
        }
        for service in services { peripheral.discoverCharacteristics(nil, for: service) }
    }

    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        if let characteristic = service.characteristics?.first(where: {
            $0.properties.contains(.write) || $0.properties.contains(.writeWithoutResponse)
        }) {
            writable[peripheral.identifier] = characteristic
            timeoutItems.removeValue(forKey: peripheral.identifier)?.cancel()
            connectContinuations.removeValue(forKey: peripheral.identifier)?.resume(returning: ())
        }
    }

    private func failConnect(_ uuid: UUID, error: Error) {
        timeoutItems.removeValue(forKey: uuid)?.cancel()
        connectContinuations.removeValue(forKey: uuid)?.resume(throwing: error)
    }

    @MainActor
    func write(identifier: String, data: Data) async throws {
        try await connect(identifier: identifier)
        guard let uuid = UUID(uuidString: identifier), let peripheral = devices[uuid], let characteristic = writable[uuid] else {
            throw NativeError.deviceNotFound
        }
        let writeType: CBCharacteristicWriteType = characteristic.properties.contains(.write) ? .withResponse : .withoutResponse
        let maxLength = max(20, peripheral.maximumWriteValueLength(for: writeType))
        var offset = 0
        while offset < data.count {
            let end = min(offset + maxLength, data.count)
            let chunk = data.subdata(in: offset..<end)
            if writeType == .withResponse {
                try await withCheckedThrowingContinuation { continuation in
                    writeContinuations[uuid] = continuation
                    peripheral.writeValue(chunk, for: characteristic, type: writeType)
                }
            } else {
                while !peripheral.canSendWriteWithoutResponse {
                    try await Task.sleep(nanoseconds: 15_000_000)
                }
                peripheral.writeValue(chunk, for: characteristic, type: writeType)
                try await Task.sleep(nanoseconds: 12_000_000)
            }
            offset = end
        }
    }

    func peripheral(_ peripheral: CBPeripheral, didWriteValueFor characteristic: CBCharacteristic, error: Error?) {
        guard let continuation = writeContinuations.removeValue(forKey: peripheral.identifier) else { return }
        if let error { continuation.resume(throwing: error) } else { continuation.resume(returning: ()) }
    }

    @MainActor
    func disconnect(identifier: String) throws {
        guard let uuid = UUID(uuidString: identifier), let peripheral = devices[uuid] else { throw NativeError.deviceNotFound }
        central.cancelPeripheralConnection(peripheral)
        writable.removeValue(forKey: uuid)
    }

    private static func looksLikePrinter(_ name: String) -> Bool {
        let lower = name.lowercased()
        return ["print", "pos", "receipt", "thermal", "epson", "star", "bixolon", "rongta", "xprinter", "sunmi", "imin", "gprinter"].contains { lower.contains($0) }
    }
}
