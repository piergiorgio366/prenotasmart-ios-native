import Foundation
import Darwin

final class BonjourDiscovery: NSObject, NetServiceBrowserDelegate, NetServiceDelegate {
    private var browsers: [NetServiceBrowser] = []
    private var services: [NetService] = []
    private var results: [String: FoundPrinter] = [:]
    private var continuation: CheckedContinuation<[FoundPrinter], Never>?
    private var finishTimer: Timer?

    func discover(seconds: TimeInterval = 3.5) async -> [FoundPrinter] {
        await withCheckedContinuation { continuation in
            DispatchQueue.main.async {
                self.continuation = continuation
                self.results.removeAll()
                self.services.removeAll()
                self.browsers.removeAll()
                for type in ["_pdl-datastream._tcp.", "_ipp._tcp.", "_ipps._tcp.", "_printer._tcp."] {
                    let browser = NetServiceBrowser()
                    browser.delegate = self
                    self.browsers.append(browser)
                    browser.searchForServices(ofType: type, inDomain: "local.")
                }
                self.finishTimer = Timer.scheduledTimer(withTimeInterval: seconds, repeats: false) { [weak self] _ in
                    self?.finish()
                }
            }
        }
    }

    private func finish() {
        browsers.forEach { $0.stop() }
        services.forEach { $0.stop() }
        finishTimer?.invalidate()
        let output = Array(results.values)
        continuation?.resume(returning: output)
        continuation = nil
    }

    func netServiceBrowser(_ browser: NetServiceBrowser, didFind service: NetService, moreComing: Bool) {
        services.append(service)
        service.delegate = self
        service.resolve(withTimeout: 2.5)
    }

    func netServiceDidResolveAddress(_ sender: NetService) {
        guard let ip = sender.addresses?.compactMap(Self.ipv4).first else { return }
        let type = sender.type.lowercased()
        let proto: String
        if type.contains("pdl-datastream") { proto = "escpos" }
        else if type.contains("printer") { proto = "lpd" }
        else { proto = "ipp" }
        let fallback = proto == "escpos" ? 9100 : (proto == "lpd" ? 515 : 631)
        let port = sender.port > 0 ? sender.port : fallback
        let printer = FoundPrinter(
            ip: ip, port: port, protocolName: proto,
            name: sender.name.isEmpty ? "Stampante di rete" : sender.name,
            manufacturer: Self.vendor(in: sender.name + " " + (sender.hostName ?? "")),
            model: nil, hostname: sender.hostName, confidence: "high"
        )
        results["\(ip):\(port)"] = printer
    }

    private static func ipv4(_ data: Data) -> String? {
        data.withUnsafeBytes { raw -> String? in
            guard let base = raw.baseAddress?.assumingMemoryBound(to: sockaddr.self),
                  base.pointee.sa_family == sa_family_t(AF_INET) else { return nil }
            var sin = raw.baseAddress!.assumingMemoryBound(to: sockaddr_in.self).pointee
            var buffer = [CChar](repeating: 0, count: Int(INET_ADDRSTRLEN))
            guard inet_ntop(AF_INET, &sin.sin_addr, &buffer, socklen_t(INET_ADDRSTRLEN)) != nil else { return nil }
            return String(cString: buffer)
        }
    }

    static func vendor(in text: String) -> String? {
        let lower = text.lowercased()
        let vendors = ["epson": "Epson", "xprinter": "XPrinter", "star": "Star Micronics", "bixolon": "Bixolon", "citizen": "Citizen", "sunmi": "Sunmi", "rongta": "Rongta", "zebra": "Zebra", "gprinter": "Gprinter", "brother": "Brother", "hp": "HP", "canon": "Canon"]
        return vendors.first(where: { lower.contains($0.key) })?.value
    }
}

