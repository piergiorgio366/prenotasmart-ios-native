import Foundation

struct FoundPrinter: Hashable {
    let ip: String
    let port: Int
    let protocolName: String
    let name: String
    var manufacturer: String?
    var model: String?
    var hostname: String?
    var confidence: String
    var online: Bool = true

    var dictionary: [String: Any] {
        [
            "ip": ip, "port": port, "protocol": protocolName, "name": name,
            "manufacturer": manufacturer ?? NSNull(), "model": model ?? NSNull(),
            "hostname": hostname ?? NSNull(), "confidence": confidence,
            "online": online, "status": online ? "online" : "offline"
        ]
    }

    static func protocolFor(port: Int) -> String {
        switch port { case 9100: return "escpos"; case 631: return "ipp"; case 515: return "lpd"; default: return "raw" }
    }
}

enum NativeError: LocalizedError {
    case invalidIP, invalidPort, networkUnavailable, connectionTimeout
    case connectionFailed(String), bluetoothDisabled, deviceNotFound
    case unsupported(String), invalidData

    var errorDescription: String? {
        switch self {
        case .invalidIP: return "Indirizzo IP non valido."
        case .invalidPort: return "Porta non valida."
        case .networkUnavailable: return "Rete Wi-Fi non disponibile."
        case .connectionTimeout: return "Connessione scaduta."
        case .connectionFailed(let message): return message
        case .bluetoothDisabled: return "Bluetooth spento o non autorizzato."
        case .deviceNotFound: return "Stampante Bluetooth non trovata."
        case .unsupported(let message): return message
        case .invalidData: return "Dati di stampa non validi."
        }
    }

    var code: String {
        switch self {
        case .invalidIP: return "INVALID_IP"
        case .invalidPort: return "INVALID_PORT"
        case .networkUnavailable: return "NETWORK_UNAVAILABLE"
        case .connectionTimeout: return "CONNECTION_TIMEOUT"
        case .connectionFailed: return "CONNECTION_FAILED"
        case .bluetoothDisabled: return "BLUETOOTH_DISABLED"
        case .deviceNotFound: return "DEVICE_NOT_PAIRED"
        case .unsupported: return "UNSUPPORTED_PROTOCOL"
        case .invalidData: return "INVALID_DATA"
        }
    }
}

