import Foundation

enum BridgeScript {
    static let source = #"""
(function () {
  'use strict';
  if (window.LanPrinter && window.LanPrinter.platform === 'ios') return;
  var handler = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.prenotaSmartNative;
  if (!handler) return;
  var pending = {}, seq = 0, TIMEOUT = 90000;
  function invoke(method, args) {
    return new Promise(function (resolve, reject) {
      var id = 'ios_' + (++seq) + '_' + Date.now();
      var timer = setTimeout(function () {
        if (!pending[id]) return;
        delete pending[id];
        var e = new Error('Tempo scaduto durante la chiamata nativa.'); e.code = 'CONNECTION_TIMEOUT'; reject(e);
      }, TIMEOUT);
      pending[id] = { resolve: resolve, reject: reject, timer: timer };
      try { handler.postMessage({ id: id, method: method, args: args || [] }); }
      catch (error) { clearTimeout(timer); delete pending[id]; reject(error); }
    });
  }
  window.__lanPrinterResolve = function (id, json) {
    var request = pending[id]; if (!request) return;
    clearTimeout(request.timer); delete pending[id];
    var data; try { data = json ? JSON.parse(json) : null; } catch (_) { data = json; }
    request.resolve(data);
  };
  window.__lanPrinterEvent = function (name, json) {
    var detail; try { detail = json ? JSON.parse(json) : null; } catch (_) { detail = json; }
    window.dispatchEvent(new CustomEvent('lanprinter:' + name, { detail: detail }));
    var callback = window.LanPrinter && window.LanPrinter['on' + name.charAt(0).toUpperCase() + name.slice(1)];
    if (typeof callback === 'function') { try { callback(detail); } catch (_) {} }
  };
  window.LanPrinter = {
    version: '1.0.0', platform: 'ios',
    getCapabilities: function () { return invoke('getCapabilities'); },
    getNetwork: function () { return invoke('getNetwork'); },
    scan: function (o) { return invoke('scan', [typeof o === 'string' ? o : JSON.stringify(o || {})]); },
    scanMdns: function () { return invoke('scanMdns'); },
    scanSubnet: function (o) { return invoke('scanSubnet', [typeof o === 'string' ? o : JSON.stringify(o || {})]); },
    stopScan: function () { return invoke('stopScan'); },
    getPrinters: function () { return invoke('getPrinters'); },
    testPrinter: function (ip, p) { return invoke('testPrinter', [ip, Number(p) || 9100]); },
    print: function (ip, p, t) { return invoke('print', [ip, Number(p) || 9100, String(t || '')]); },
    printEscPos: function (ip, p, b) { return invoke('printEscPos', [ip, Number(p) || 9100, b]); },
    getPrinterStatus: function (ip, p) { return invoke('getPrinterStatus', [ip, Number(p) || 9100]); },
    getBluetoothPrinters: function () { return invoke('getBluetoothPrinters'); },
    connectBluetooth: function (a) { return invoke('connectBluetooth', [a]); },
    writeBluetoothChunk: function (a, b) { return invoke('writeBluetoothChunk', [a, b]); },
    disconnectBluetooth: function (a) { return invoke('disconnectBluetooth', [a]); },
    testBluetooth: function (a) { return invoke('testBluetooth', [a]); },
    printBluetooth: function (a, t) { return invoke('printBluetooth', [a, String(t || '')]); },
    printBluetoothEscPos: function (a, b) { return invoke('printBluetoothEscPos', [a, b]); },
    getUsbPrinters: function () { return invoke('getUsbPrinters'); },
    testUsb: function (d) { return invoke('testUsb', [Number(d)]); },
    printUsb: function (d, t) { return invoke('printUsb', [Number(d), String(t || '')]); },
    printUsbEscPos: function (d, b) { return invoke('printUsbEscPos', [Number(d), b]); }
  };
  var detail = { version: '1.0.0', lan: true, bluetooth: true, usb: false };
  window.dispatchEvent(new CustomEvent('prenotasmart:native-ready', { detail: detail }));
  window.dispatchEvent(new CustomEvent('lanprinter:ready', { detail: detail }));
  console.info('[NativePrint] Bridge iOS PrenotaSmart 1.0.0 disponibile');
})();
"""#
}
