import Foundation
import Network

final class LanPrinterManager {
    private let queue = DispatchQueue(label: "app.prenotasmart.lan", qos: .userInitiated, attributes: .concurrent)
    private let cacheQueue = DispatchQueue(label: "app.prenotasmart.printer-cache")
    private var cache: [String: FoundPrinter] = [:]
    private var cancelled = false

    func stop() { cacheQueue.sync { cancelled = true } }
    func cachedPrinters() -> [FoundPrinter] { cacheQueue.sync { Array(cache.values) } }

    func scan(
        mdns: Bool,
        subnet: Bool,
        ports: [Int],
        onFound: @escaping (FoundPrinter) -> Void,
        onProgress: @escaping (Int) -> Void
    ) async throws -> [FoundPrinter] {
        cacheQueue.sync { cancelled = false }
        if mdns {
            let found = await BonjourDiscovery().discover()
            for printer in found { remember(printer); onFound(printer) }
        }
        if subnet {
            let hosts = try NetworkInfo.hosts()
            let batches = stride(from: 0, to: hosts.count, by: 28).map {
                Array(hosts[$0..<min($0 + 28, hosts.count)])
            }
            var completed = 0
            for batch in batches {
                if cacheQueue.sync(execute: { cancelled }) { break }
                await withTaskGroup(of: FoundPrinter?.self) { group in
                    for host in batch {
                        group.addTask { [weak self] in await self?.probe(host: host, ports: ports) }
                    }
                    for await result in group {
                        completed += 1
                        onProgress(Int(Double(completed) / Double(hosts.count) * 100.0))
                        if let printer = result { remember(printer); onFound(printer) }
                    }
                }
            }
        }
        onProgress(100)
        return cachedPrinters().sorted { $0.ip.localizedStandardCompare($1.ip) == .orderedAscending }
    }

    private func remember(_ printer: FoundPrinter) {
        cacheQueue.sync {
            let key = "\(printer.ip):\(printer.port)"
            if var old = cache[key] {
                if old.manufacturer == nil { old.manufacturer = printer.manufacturer }
                if old.hostname == nil { old.hostname = printer.hostname }
                if printer.confidence == "high" { old.confidence = "high" }
                cache[key] = old
            } else { cache[key] = printer }
        }
    }

    private func probe(host: String, ports: [Int]) async -> FoundPrinter? {
        for port in ports where (1...65535).contains(port) {
            if await isOpen(host: host, port: port, timeout: 0.38) {
                let protocolName = FoundPrinter.protocolFor(port: port)
                let name: String
                switch port { case 9100: name = "Possibile stampante POS"; case 631: name = "Stampante IPP"; case 515: name = "Stampante LPD"; default: name = "Dispositivo di stampa" }
                return FoundPrinter(ip: host, port: port, protocolName: protocolName, name: name, manufacturer: nil, model: nil, hostname: nil, confidence: port == 9100 ? "medium" : "low")
            }
        }
        return nil
    }

    func isOpen(host: String, port: Int, timeout: TimeInterval = 1.2) async -> Bool {
        guard let nwPort = NWEndpoint.Port(rawValue: UInt16(port)) else { return false }
        return await withCheckedContinuation { continuation in
            let connection = NWConnection(host: NWEndpoint.Host(host), port: nwPort, using: .tcp)
            let lock = NSLock()
            var finished = false
            func finish(_ value: Bool) {
                lock.lock(); defer { lock.unlock() }
                guard !finished else { return }
                finished = true
                connection.cancel()
                continuation.resume(returning: value)
            }
            connection.stateUpdateHandler = { state in
                switch state { case .ready: finish(true); case .failed, .cancelled: finish(false); default: break }
            }
            connection.start(queue: queue)
            queue.asyncAfter(deadline: .now() + timeout) { finish(false) }
        }
    }

    func send(host: String, port: Int, data: Data) async throws {
        try NetworkInfo.validate(ip: host, port: port)
        guard let nwPort = NWEndpoint.Port(rawValue: UInt16(port)) else { throw NativeError.invalidPort }
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            let connection = NWConnection(host: NWEndpoint.Host(host), port: nwPort, using: .tcp)
            let lock = NSLock()
            var finished = false
            func finish(_ result: Result<Void, Error>) {
                lock.lock(); defer { lock.unlock() }
                guard !finished else { return }
                finished = true
                connection.cancel()
                continuation.resume(with: result)
            }
            connection.stateUpdateHandler = { state in
                switch state {
                case .ready:
                    connection.send(content: data, completion: .contentProcessed { error in
                        if let error { finish(.failure(NativeError.connectionFailed(error.localizedDescription))) }
                        else { finish(.success(())) }
                    })
                case .failed(let error): finish(.failure(NativeError.connectionFailed(error.localizedDescription)))
                case .cancelled: break
                default: break
                }
            }
            connection.start(queue: queue)
            queue.asyncAfter(deadline: .now() + 6) { finish(.failure(NativeError.connectionTimeout)) }
        }
    }
}
