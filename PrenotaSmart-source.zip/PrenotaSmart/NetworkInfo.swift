import Foundation
import Darwin

enum NetworkInfo {
    static func wifiIPv4() -> String? {
        var interfaces: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&interfaces) == 0, let first = interfaces else { return nil }
        defer { freeifaddrs(interfaces) }

        var cursor: UnsafeMutablePointer<ifaddrs>? = first
        while let current = cursor {
            let item = current.pointee
            if item.ifa_addr.pointee.sa_family == UInt8(AF_INET),
               String(cString: item.ifa_name) == "en0" {
                var host = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                let length = socklen_t(item.ifa_addr.pointee.sa_len)
                if getnameinfo(item.ifa_addr, length, &host, socklen_t(host.count), nil, 0, NI_NUMERICHOST) == 0 {
                    return String(cString: host)
                }
            }
            cursor = item.ifa_next
        }
        return nil
    }

    static func dictionary() throws -> [String: Any] {
        guard let ip = wifiIPv4() else { throw NativeError.networkUnavailable }
        let parts = ip.split(separator: ".")
        let subnet = parts.count == 4 ? "\(parts[0]).\(parts[1]).\(parts[2]).0" : nil
        return [
            "ip": ip,
            "gateway": NSNull(),
            "cidr": subnet.map { "\($0)/24" } ?? NSNull(),
            "subnet": subnet ?? NSNull(),
            "ssid": NSNull()
        ]
    }

    static func hosts() throws -> [String] {
        guard let ip = wifiIPv4() else { throw NativeError.networkUnavailable }
        let parts = ip.split(separator: ".")
        guard parts.count == 4 else { throw NativeError.networkUnavailable }
        let base = "\(parts[0]).\(parts[1]).\(parts[2])"
        return (1...254).map { "\(base).\($0)" }.filter { $0 != ip }
    }

    static func validate(ip: String, port: Int) throws {
        var address = in_addr()
        guard inet_pton(AF_INET, ip, &address) == 1 else { throw NativeError.invalidIP }
        guard (1...65535).contains(port) else { throw NativeError.invalidPort }
    }
}

