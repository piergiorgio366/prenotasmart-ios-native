import Foundation

enum ESCPos {
    static func text(_ value: String) -> Data {
        var data = Data([0x1B, 0x40])
        let normalized = value.replacingOccurrences(of: "\n", with: "\r\n")
        data.append(normalized.data(using: .isoLatin1, allowLossyConversion: true) ?? Data())
        data.append(contentsOf: [0x0A, 0x1B, 0x64, 0x03, 0x1D, 0x56, 0x01])
        return data
    }

    static func testTicket(ip: String, port: Int) -> Data {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "it_IT")
        formatter.dateFormat = "dd/MM/yyyy HH:mm:ss"
        var data = Data([0x1B, 0x40, 0x1B, 0x61, 0x01, 0x1D, 0x21, 0x11, 0x1B, 0x45, 0x01])
        data.append("TEST STAMPANTE\r\n".data(using: .isoLatin1)!)
        data.append(contentsOf: [0x1B, 0x45, 0x00, 0x1D, 0x21, 0x00])
        let body = "\r\nConnessione riuscita\r\n\r\nIP:    \(ip)\r\nPorta: \(port)\r\nData:  \(formatter.string(from: Date()))\r\n--------------------------------\r\nPrenotaSmart iOS\r\n"
        data.append(body.data(using: .isoLatin1, allowLossyConversion: true)!)
        data.append(contentsOf: [0x1B, 0x64, 0x03, 0x1D, 0x56, 0x01])
        return data
    }
}
