import Foundation
import WebKit

final class NativeBridge: NSObject, WKScriptMessageHandler {
    weak var webView: WKWebView?
    private let lan = LanPrinterManager()
    private let bluetooth = BLEPrinterManager()

    init(webView: WKWebView) {
        self.webView = webView
        super.init()
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.name == "prenotaSmartNative",
              let body = message.body as? [String: Any],
              let id = body["id"] as? String,
              let method = body["method"] as? String else { return }
        let args = body["args"] as? [Any] ?? []
        Task { await execute(id: id, method: method, args: args) }
    }

    private func int(_ value: Any?, fallback: Int = 0) -> Int {
        if let number = value as? NSNumber { return number.intValue }
        if let string = value as? String { return Int(string) ?? fallback }
        return fallback
    }

    private func string(_ value: Any?) -> String { value as? String ?? "" }

    @MainActor
    private func execute(id: String, method: String, args: [Any]) async {
        do {
            let result: Any
            switch method {
            case "getCapabilities":
                result = ["lan": true, "bluetooth": true, "usb": false, "platform": "ios", "version": "1.0.0"]
            case "getNetwork":
                result = try NetworkInfo.dictionary()
            case "scan", "scanMdns", "scanSubnet":
                var mdns = method != "scanSubnet"
                var subnet = method != "scanMdns"
                var ports = [9100, 631, 515]
                if method == "scan", let optionsString = args.first as? String,
                   let data = optionsString.data(using: .utf8),
                   let options = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
                    if let value = options["mdns"] as? Bool { mdns = value }
                    if let value = options["subnet"] as? Bool { subnet = value }
                    if let value = options["ports"] as? [NSNumber] { ports = value.map(\.intValue).filter { (1...65535).contains($0) } }
                }
                let printers = try await lan.scan(mdns: mdns, subnet: subnet, ports: ports, onFound: { [weak self] printer in
                    self?.emit("printerFound", value: printer.dictionary)
                }, onProgress: { [weak self] percent in
                    self?.emit("scanProgress", value: ["percent": percent])
                })
                emit("scanFinished", value: ["count": printers.count])
                result = ["network": try NetworkInfo.dictionary(), "printers": printers.map(\.dictionary)]
            case "stopScan":
                lan.stop(); result = ["stopped": true]
            case "getPrinters":
                result = ["printers": lan.cachedPrinters().map(\.dictionary)]
            case "testPrinter":
                let ip = string(args[safe: 0]), port = int(args[safe: 1], fallback: 9100)
                try await lan.send(host: ip, port: port, data: ESCPos.testTicket(ip: ip, port: port)); result = ["ok": true]
            case "print":
                let ip = string(args[safe: 0]), port = int(args[safe: 1], fallback: 9100)
                try await lan.send(host: ip, port: port, data: ESCPos.text(string(args[safe: 2]))); result = ["ok": true]
            case "printEscPos":
                guard let data = Data(base64Encoded: string(args[safe: 2]), options: .ignoreUnknownCharacters) else { throw NativeError.invalidData }
                try await lan.send(host: string(args[safe: 0]), port: int(args[safe: 1], fallback: 9100), data: data); result = ["ok": true]
            case "getPrinterStatus":
                let online = await lan.isOpen(host: string(args[safe: 0]), port: int(args[safe: 1], fallback: 9100))
                result = ["status": online ? "online" : "offline"]
            case "getBluetoothPrinters":
                let printers = try await bluetooth.scan(); result = ["printers": printers, "enabled": true]
            case "connectBluetooth":
                let address = string(args[safe: 0]); try await bluetooth.connect(identifier: address)
                result = ["connected": true, "address": address]
            case "writeBluetoothChunk":
                guard let data = Data(base64Encoded: string(args[safe: 1]), options: .ignoreUnknownCharacters) else { throw NativeError.invalidData }
                try await bluetooth.write(identifier: string(args[safe: 0]), data: data); result = ["ok": true]
            case "disconnectBluetooth":
                let address = string(args[safe: 0]); try bluetooth.disconnect(identifier: address)
                result = ["connected": false, "address": address]
            case "testBluetooth":
                let address = string(args[safe: 0]); try await bluetooth.write(identifier: address, data: ESCPos.testTicket(ip: "BLE", port: 0)); result = ["ok": true]
            case "printBluetooth":
                try await bluetooth.write(identifier: string(args[safe: 0]), data: ESCPos.text(string(args[safe: 1]))); result = ["ok": true]
            case "printBluetoothEscPos":
                guard let data = Data(base64Encoded: string(args[safe: 1]), options: .ignoreUnknownCharacters) else { throw NativeError.invalidData }
                try await bluetooth.write(identifier: string(args[safe: 0]), data: data); result = ["ok": true]
            case "getUsbPrinters":
                result = ["printers": [], "supported": false]
            case "testUsb", "printUsb", "printUsbEscPos":
                throw NativeError.unsupported("iPhone non supporta stampanti USB host generiche. Usa LAN, BLE o un modello MFi.")
            default:
                throw NativeError.unsupported("Metodo nativo non disponibile: \(method)")
            }
            resolve(id, value: result)
        } catch {
            let native = error as? NativeError
            resolve(id, value: ["error": native?.code ?? "UNKNOWN_ERROR", "message": error.localizedDescription])
        }
    }

    private func resolve(_ id: String, value: Any) {
        guard let json = Self.jsonString(value), let quotedId = Self.jsonString(id) else { return }
        DispatchQueue.main.async { [weak self] in
            self?.webView?.evaluateJavaScript("window.__lanPrinterResolve(\(quotedId), JSON.stringify(\(json)));", completionHandler: nil)
        }
    }

    private func emit(_ name: String, value: Any) {
        guard let json = Self.jsonString(value), let quotedName = Self.jsonString(name) else { return }
        DispatchQueue.main.async { [weak self] in
            self?.webView?.evaluateJavaScript("window.__lanPrinterEvent(\(quotedName), JSON.stringify(\(json)));", completionHandler: nil)
        }
    }

    private static func jsonString(_ value: Any) -> String? {
        if let string = value as? String,
           let data = try? JSONSerialization.data(withJSONObject: [string]),
           let array = String(data: data, encoding: .utf8) {
            return String(array.dropFirst().dropLast())
        }
        guard JSONSerialization.isValidJSONObject(value), let data = try? JSONSerialization.data(withJSONObject: value) else { return nil }
        return String(data: data, encoding: .utf8)
    }
}

private extension Array {
    subscript(safe index: Index) -> Element? { indices.contains(index) ? self[index] : nil }
}
