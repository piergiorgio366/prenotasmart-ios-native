# PrenotaSmart iOS

Contenitore iPhone/iPad nativo per `https://prenota-smart.app`, compatibile con
la API JavaScript `window.LanPrinter` usata dalla versione Android 1.4.0.

## Funzioni incluse

- WKWebView con bridge JavaScript ↔ Swift iniettato prima del caricamento pagina.
- Stampa ESC/POS via TCP/IP (porta 9100 o porta configurata).
- Scansione mirata della sottorete Wi-Fi sulle porte 9100, 631 e 515.
- Discovery Bonjour/mDNS per `_pdl-datastream`, `_ipp`, `_ipps` e `_printer`.
- Stato, prova di stampa, invio testo e invio ESC/POS Base64.
- Bluetooth Low Energy: scansione, connessione, ricerca automatica della
  characteristic scrivibile e stampa ESC/POS.
- Log nativo consultabile dalla console Xcode.

## Limiti reali di iOS

- iOS non espone il Bluetooth Classic SPP generico usato da molte stampanti POS
  economiche. Queste funzionano su Android ma su iPhone richiedono BLE, AirPrint,
  rete LAN oppure un SDK MFi del produttore.
- iPhone non supporta stampanti USB host generiche come Android; la relativa API
  resta presente per compatibilità ma restituisce `UNSUPPORTED_PROTOCOL`.
- Il nome SSID può rimanere vuoto senza l'entitlement Wi-Fi Information. La
  scansione LAN e la stampa via IP funzionano comunque.

## Aprire e compilare

1. Copia la cartella su un Mac con Xcode 16 o successivo.
2. Apri `PrenotaSmart.xcodeproj`.
3. In **Signing & Capabilities** scegli il tuo Team Apple e, se necessario,
   cambia il Bundle Identifier `app.prenotasmart.ios` con uno univoco.
4. Collega l'iPhone, selezionalo come destinazione e premi Run.
5. Alla prima scansione autorizza **Rete locale**; alla prima ricerca BLE
   autorizza **Bluetooth**.

## Creare IPA

In Xcode seleziona **Any iOS Device (arm64)**, quindi **Product → Archive**.
Nell'Organizer scegli **Distribute App**. Un IPA installabile deve essere firmato
con un certificato/profilo Apple valido; non può essere prodotto su Linux o
firmato senza il tuo Team Apple.

## Compilare online con Codemagic

Il repository include `codemagic.yaml` con due workflow:

- `ios-unsigned`: genera un IPA non firmato senza account Apple Developer;
  successivamente deve essere firmato con Sideloadly/AltStore o equivalente.
- `ios-signed`: genera un IPA Development firmato. Richiede in Codemagic una
  integrazione App Store Connect chiamata `codemagic`, un certificato valido e
  un provisioning profile per `app.prenotasmart.ios`.

## Prova rapida dalla console della webapp

```javascript
await window.LanPrinter.getCapabilities()
await window.LanPrinter.scan({ mdns: true, subnet: true, ports: [9100, 631, 515] })
await window.LanPrinter.testPrinter('192.168.1.50', 9100)
```

Per BLE:

```javascript
const result = await window.LanPrinter.getBluetoothPrinters()
await window.LanPrinter.testBluetooth(result.printers[0].address)
```
